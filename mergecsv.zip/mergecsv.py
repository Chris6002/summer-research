import csv
import os
current_folder=os.path.dirname(os.path.realpath(__file__))

inputcsv_list=[os.path.join(current_folder,'hehe/1.csv'),os.path.join(current_folder,'hehe/2.csv'),os.path.join(current_folder,'hehe/3.csv'),os.path.join(current_folder,'hehe/test.csv')]
outputcsv=os.path.join(current_folder,'hehe/mergeall.csv')
with open(os.path.join(current_folder,'hehe/test.csv')) as csv_file, open(outputcsv, 'w') as out_file:
    csv_reader = csv.DictReader(csv_file)
    new_header = csv_reader.fieldnames
    csv_writer = csv.DictWriter(out_file, new_header)
    csv_writer.writeheader()
with open(outputcsv, 'a') as out_file:
    for index, inputcsv in enumerate(inputcsv_list):
        print(inputcsv)
        with open(inputcsv) as csv_file:
            csv_reader = csv.DictReader(csv_file)
            csv_writer = csv.DictWriter(out_file, new_header)
            for row in csv_reader:
                row.pop('stage', None)
                row.pop('useful',None)
                csv_writer.writerow(row)

# with open(os.path.join(current_folder,'mergeall.csv')) as inputcsv:
#     reader=csv.DictReader(inputcsv)
#     for i in reader:
#         print(i['name'],i['steering'],i['frame'])